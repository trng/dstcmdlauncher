Macro {
  description="Tilt mouse wheel Left";
  area="Shell";
  key="MsM2Click";
  action = function()
    Keys("CtrlPgUp")
  end;
}

Macro {
  description="Tilt mouse wheel Right";
  area="Shell";
  key="MsM3Click";
  action = function()
    Keys("CtrlPgDn")
  end;
}
